import { City } from './city';

export class Theatre {
    id:number;
    name:String;
    city:City;
}
