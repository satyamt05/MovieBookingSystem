import { MovieIdValidator } from './movie-id-validator';

describe('MovieIdValidator', () => {
  it('should create an instance', () => {
    expect(new MovieIdValidator()).toBeTruthy();
  });
});
