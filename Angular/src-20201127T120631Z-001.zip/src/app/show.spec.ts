import { Show } from './show';

describe('Show', () => {
  it('should create an instance', () => {
    expect(new Show()).toBeTruthy();
  });
});
