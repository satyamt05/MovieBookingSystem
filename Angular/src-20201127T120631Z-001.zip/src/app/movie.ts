export class Movie {

    id:number;
    name:String;
    director:String;
    language:String;
    releaseDate:Date;
}
