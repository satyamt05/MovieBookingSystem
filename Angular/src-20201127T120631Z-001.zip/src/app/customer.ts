export class Customer {
    id:number;
    contact:number;
    dateOfBirth:Date;
    name:string;
    password:String;
    
}
