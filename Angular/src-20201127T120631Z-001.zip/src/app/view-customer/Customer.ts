export class Customer{
    id:number;
    name:String;
    password:String;
    dateOfBirth:String;
    contact:number;
}