import { Theatre } from './theatre';
export class Screen {
    id: number;
    name: String;
    theatreId:Theatre;
}
