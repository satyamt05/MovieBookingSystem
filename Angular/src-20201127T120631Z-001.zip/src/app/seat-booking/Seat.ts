import { Booking } from '../add-booking/booking';

export class Seat {  
  
    seatId:number;  
    seatNumber:String;  
    seatStatus:String;
    booking:Booking;

    
}  