export class City {
    id: number;
    name: String;
}
