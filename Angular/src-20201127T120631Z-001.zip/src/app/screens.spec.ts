import { Screen } from "./screen";

describe('Screen', () => {
  it('should create an instance', () => {
    expect(new Screen()).toBeTruthy();
  });
});
