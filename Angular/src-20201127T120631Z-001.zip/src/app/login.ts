export class Login {
    id:number;
    password:String;
    name:String;
    contact:number;
}
