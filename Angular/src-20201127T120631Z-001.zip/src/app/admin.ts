export class Admin {
    id:number;
    name:string;
    password:String;
    contact:number;
}
